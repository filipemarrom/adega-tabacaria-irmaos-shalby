# Adega & Tabacaria Irmãos Shalby

Sistema simples para cadastrar produtos e registrar vendas, com controle de estoque.

## Como rodar localmente

1. `npm install`  
2. `npm run dev`  
3. Acesse `http://localhost:5173`

## Como publicar

1. Crie repositório no GitHub  
2. Faça push do projeto  
3. Importe no Vercel e clique em Deploy