import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

export default function AdegaTabacariaApp() {
  const [produtos, setProdutos] = useState([]);
  const [vendas, setVendas] = useState([]);
  const [novoProduto, setNovoProduto] = useState({ nome: "", categoria: "", precoCompra: "", precoVenda: "", estoque: "" });
  const [novaVenda, setNovaVenda] = useState({ nome: "", quantidade: "" });
  const [erro, setErro] = useState("");

  const adicionarProduto = () => {
    if (!novoProduto.nome || !novoProduto.precoVenda || !novoProduto.estoque) {
      setErro("Preencha os campos obrigatórios.");
      return;
    }
    setProdutos([...produtos, { ...novoProduto, id: Date.now() }]);
    setNovoProduto({ nome: "", categoria: "", precoCompra: "", precoVenda: "", estoque: "" });
    setErro("");
  };

  const registrarVenda = () => {
    const produto = produtos.find(p => p.nome.toLowerCase() === novaVenda.nome.toLowerCase());
    if (!produto) {
      setErro("Produto não encontrado.");
      return;
    }
    if (Number(produto.estoque) < Number(novaVenda.quantidade)) {
      setErro("Estoque insuficiente.");
      return;
    }

    const novaListaProdutos = produtos.map(p =>
      p.nome === produto.nome ? { ...p, estoque: Number(p.estoque) - Number(novaVenda.quantidade) } : p
    );

    setProdutos(novaListaProdutos);
    setVendas([
      ...vendas,
      {
        ...novaVenda,
        data: new Date().toLocaleDateString(),
        total: Number(produto.precoVenda) * Number(novaVenda.quantidade)
      }
    ]);
    setNovaVenda({ nome: "", quantidade: "" });
    setErro("");
  };

  return (
    <div className="p-4 grid gap-4">
      <h1 className="text-2xl font-bold">Adega & Tabacaria Irmãos Shalby</h1>

      {erro && <div className="text-red-500 font-semibold">{erro}</div>}

      <Card>
        <CardContent className="p-4 grid gap-2">
          <h2 className="text-xl font-semibold">Cadastrar Produto</h2>
          <div className="grid grid-cols-2 gap-2">
            <Input placeholder="Nome" value={novoProduto.nome} onChange={e => setNovoProduto({ ...novoProduto, nome: e.target.value })} />
            <Input placeholder="Categoria" value={novoProduto.categoria} onChange={e => setNovoProduto({ ...novoProduto, categoria: e.target.value })} />
            <Input placeholder="Preço de Compra" type="number" value={novoProduto.precoCompra} onChange={e => setNovoProduto({ ...novoProduto, precoCompra: e.target.value })} />
            <Input placeholder="Preço de Venda" type="number" value={novoProduto.precoVenda} onChange={e => setNovoProduto({ ...novoProduto, precoVenda: e.target.value })} />
            <Input placeholder="Estoque" type="number" value={novoProduto.estoque} onChange={e => setNovoProduto({ ...novoProduto, estoque: e.target.value })} />
          </div>
          <Button onClick={adicionarProduto}>Adicionar Produto</Button>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-4 grid gap-2">
          <h2 className="text-xl font-semibold">Registrar Venda</h2>
          <div className="grid grid-cols-2 gap-2">
            <Input placeholder="Nome do Produto" value={novaVenda.nome} onChange={e => setNovaVenda({ ...novaVenda, nome: e.target.value })} />
            <Input placeholder="Quantidade" type="number" value={novaVenda.quantidade} onChange={e => setNovaVenda({ ...novaVenda, quantidade: e.target.value })} />
          </div>
          <Button onClick={registrarVenda}>Registrar Venda</Button>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-4">
          <h2 className="text-xl font-semibold">Estoque</h2>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Nome</TableHead>
                <TableHead>Categoria</TableHead>
                <TableHead>Estoque</TableHead>
                <TableHead>Venda (R$)</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {produtos.map(p => (
                <TableRow key={p.id} className={Number(p.estoque) < 5 ? "bg-red-100" : ""}>
                  <TableCell>{p.nome}</TableCell>
                  <TableCell>{p.categoria}</TableCell>
                  <TableCell>{p.estoque}</TableCell>
                  <TableCell>{Number(p.precoVenda).toFixed(2)}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-4">
          <h2 className="text-xl font-semibold">Histórico de Vendas</h2>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Data</TableHead>
                <TableHead>Produto</TableHead>
                <TableHead>Quantidade</TableHead>
                <TableHead>Total (R$)</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {vendas.map((v, i) => (
                <TableRow key={i}>
                  <TableCell>{v.data}</TableCell>
                  <TableCell>{v.nome}</TableCell>
                  <TableCell>{v.quantidade}</TableCell>
                  <TableCell>{v.total.toFixed(2)}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}